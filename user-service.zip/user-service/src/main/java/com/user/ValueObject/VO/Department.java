package com.user.ValueObject.VO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Department {
	
	private Long DepartmentId;
	private String DepartmentName;
	private String DepartmentAddress;
	private String DepartmentCode;
	public Long getDepartmentId() {
		return DepartmentId;
	}
	public void setDepartmentId(Long departmentId) {
		DepartmentId = departmentId;
	}
	public String getDepartmentName() {
		return DepartmentName;
	}
	public void setDepartmentName(String departmentName) {
		DepartmentName = departmentName;
	}
	public String getDepartmentAddress() {
		return DepartmentAddress;
	}
	public void setDepartmentAddress(String departmentAddress) {
		DepartmentAddress = departmentAddress;
	}
	public String getDepartmentCode() {
		return DepartmentCode;
	}
	public void setDepartmentCode(String departmentCode) {
		DepartmentCode = departmentCode;
	}
	
}
