package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.user.ValueObject.VO.Department;
import com.user.ValueObject.VO.ResponseTemplateVO_usertodept;
import com.user.entity.User;
import com.user.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userrepository;
	
	@Autowired
	private RestTemplate restTemplate;

	public User saveUser(User user) {
		// TODO Auto-generated method stub
		System.out.println("saved");
		return userrepository.save(user);
	}

	public ResponseTemplateVO_usertodept getUserWithDepartment(Long userId) {
		// TODO Auto-generated method stub
		ResponseTemplateVO_usertodept vo=new ResponseTemplateVO_usertodept();
		User user=UserRepository.findByUserId(userId);//http://localhost:9001/departments/
		Department department=restTemplate.getForObject("http://localhost:9001/departments/" +user.getDepartmentId(), Department.class);
        vo.setUser(user);
        vo.setDepartment(department);
		return vo;
	}
}
