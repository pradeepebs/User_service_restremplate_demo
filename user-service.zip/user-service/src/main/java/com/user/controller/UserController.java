package com.user.controller;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.user.ValueObject.VO.ResponseTemplateVO_usertodept;
import com.user.entity.User;
import com.user.service.UserService;

import lombok.extern.log4j.Log4j;

@RestController
@RequestMapping("/users")
public class UserController {
	
 //  private static final Logger LOG = Logger.getLogger(UserController.class);
    //Logger logger = Logger.getLogger(MyClass.class.getName());

	@Autowired
	private UserService userservice;
    @PostMapping("/")
	public User saveUser(@RequestBody User user) {
    	System.out.println("saved method");
    	//	LOG.info("inside the save");

		return userservice.saveUser(user);
	}

    @GetMapping("/{id}")
    public ResponseTemplateVO_usertodept getUserWithDepartment(@PathVariable("id") Long userId) {
    	System.out.println("get method");

	return userservice.getUserWithDepartment(userId);
	//LOG.info("inside the save");

}
	

}
